#ifndef STEVENTCUTS_H
#define STEVENTCUTS_H
class StEventCuts:public StCuts{
    public
        StEventCuts(){}
        virtual ~StEventCuts(){}
        virtual Bool_t CheckCuts(const StEventInfo& evtInfo){
            if
	}
    
}
#endif
