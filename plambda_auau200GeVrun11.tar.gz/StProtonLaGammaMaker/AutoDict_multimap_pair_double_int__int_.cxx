#include "StRefMultCorr.h"
#include "utility"
#ifdef __CINT__ 
#pragma link C++ nestedclasses;
#pragma link C++ nestedtypedefs;
#pragma link C++ class multimap<pair<double,int>,int>+;
#pragma link C++ class multimap<pair<double,int>,int>::*;
#pragma link C++ operators multimap<pair<double,int>,int>::iterator;
#pragma link C++ operators multimap<pair<double,int>,int>::const_iterator;
#pragma link C++ operators multimap<pair<double,int>,int>::reverse_iterator;
#endif
