#include "StErfEffMaker.h"
#include "TF1.h"
#ifdef __CINT__ 
#pragma link C++ nestedclasses;
#pragma link C++ nestedtypedefs;
#pragma link C++ class random_access_iterator<TF1,long>+;
#pragma link C++ class random_access_iterator<TF1,long>::*+;
#endif
